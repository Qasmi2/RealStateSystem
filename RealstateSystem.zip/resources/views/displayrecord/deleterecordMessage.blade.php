@extends('layouts.app')

@section('content')


<div class="container" style="margin-top:60px;">
    <div class="row justify-content-center">
        <div class="col-md-10 col-lg-10 col-sm-12 col-xs-12 offset-md-3 offset-lg-3">
            <div class="card">
                <div class="card-header" style="background-color: #f44336;color:white;">Removed Record </div>
                   
                </div>
            </div>
        </div>
    </div>
</div>
                    
@endsection