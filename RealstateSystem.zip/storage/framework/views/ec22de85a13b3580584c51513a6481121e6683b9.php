<?php $__env->startSection('content'); ?>

<?php 
    $property = array($property);
    $payment = array($payment);
    $applicant = array($applicant);
    $review = array($review);
    $token = array($token);
   
    foreach($property as $pr){
        $PropertyJoint =  $pr->jointProperty;
        $sellerId = $pr->propertySellerId;
        if($PropertyJoint == 0)
        {
            $PropertyJoint = "No";
        }
        if($PropertyJoint == 1)
        {
            $PropertyJoint = "Yes";
        }
    }
    // seller info
    foreach($seller as $te){
        if( $te->id == $sellerId)
        {
            $id =  $te->id;
            $sname =  $te->sallerName; 
            $sfatherName =  $te->sellerFatherName;
            $sdesignation = $te->sallerDesignation;
            $scnicNo = $te->sallerCnicNo;
        }
       
    }
   
?>
<div class="container" style="margin-top:60px;">
    <div class="row justify-content-center">
        <div class="col-md-9 col-lg-9 col-sm-12 col-xs-12 offset-md-3 offset-lg-3">
        <?php echo $__env->make('flash-message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <div class="card">
                <div class="card-header" style="background-color: #f44336;color:white;"> Registion Form Updating</div>

                <div class="card-body">
                    <div><h3>Property Information</h3></div>
                    <hr>
                    &nbsp;&nbsp;
                    &nbsp;
                <?php $__currentLoopData = $property; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $te): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <form method="POST"  action="<?php echo e(url('updating/'.$te->id)); ?>" enctype="multipart/form-data" value="PATCH">
                        <?php echo e(csrf_field()); ?>

                        <div class="form-group row">
                            <div class="col-md-4 col-lg-4 col-sm-12">
                                <label for="propertyType" ><?php echo e(__('Registion Project')); ?></label>
                                <!-- <input id="propertyType" type="propertyType" placeholder="Enter REGISTERED PROJECT " class="form-control<?php echo e($errors->has('propertyType') ? ' is-invalid' : ''); ?>" name="propertyType" value="<?php echo e($te->propertyType); ?>" required> -->
                                <select class="form-control" name="propertyType" id="propertyType" >
                                    <option value="<?php echo e($te->propertyType); ?>"><?php echo e($te->propertyType); ?></option>
                                    <option value="Montviro Hotal">Montviro Hotal</option>
                                    <option value="Montviro Mall">Montviro Mall</option>
                                    <option value="Montviro Theme Park">Montviro Theme Park</option>
                                </select>
                                <?php if($errors->has('propertyType')): ?>
                                    <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('propertyType')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="col-md-4 col-lg-4 col-sm-12">
                                <label for="registrationStatus"><?php echo e(__('Registration Status')); ?></label>
                                <!-- <input id="registrationStatus" type="text" placeholder="Select Registration Status " class="form-control<?php echo e($errors->has('registrationStatus') ? ' is-invalid' : ''); ?>" name="registrationStatus" value="<?php echo e($te->registrationStatus); ?>" required> -->
                                <select class="form-control" name="registrationStatus" id="registrationStatus" >
                                    <option value="<?php echo e($te->registrationStatus); ?>"><?php echo e($te->registrationStatus); ?></option>
                                    <option value="First Alottee">First Alottee</option>
                                    <option value="Transfer Certificate">Transfer Certificate</option>
                                    <option value="Open Certificate">Open Certificate</option>
                                </select>
                                <?php if($errors->has('registrationStatus')): ?>
                                    <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('registrationStatus')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        <!-- </div>
                        <div class="form-group row"> -->
                            <div class="col-md-4 col-lg-4 col-sm-12">
                                <label for="propertySection"><?php echo e(__('Property Section')); ?></label>
                                <!-- <input id="propertySection" type="text" placeholder="Enter property Section " class="form-control<?php echo e($errors->has('propertySection') ? ' is-invalid' : ''); ?>" name="propertySection" value="<?php echo e($te->propertySection); ?>"  required> -->
                                <select class="form-control" name="propertySection" id="propertySection" >
                                    <option value="<?php echo e($te->propertySection); ?>"><?php echo e($te->propertySection); ?></option>
                                    <option value="Office">Office</option>
                                    <option value="Shop">Shop</option>
                                    <option value="Suite">Suite</option>
                                    <option value="Food Court">Food Court</option>
                                    <option value="Kiosk">Kiosk</option>
                                    <option value="Theme Park">Theme Park</option>
                                </select>
                                <?php if($errors->has('propertySection')): ?>
                                    <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('propertySection')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                           
                        </div>
                        <div class="form-group row">
                            <div class="col-md-6 col-lg-6 col-sm-12">
                                <label for="propertyAddress"><?php echo e(__('Property Address (Floor No.)')); ?></label>
                                <input id="Property Address" type="number" min="0" placeholder="Enter Floor No. " class="form-control<?php echo e($errors->has('propertyAddress') ? ' is-invalid' : ''); ?>" name="propertyAddress" value="<?php echo e($te->propertyAddress); ?>" >
                                <?php if($errors->has('propertyAddress')): ?>
                                    <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('propertyAddress')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        <!-- </div>
                        <div class="form-group row"> -->
                            <div class="col-md-6 col-lg-6 col-sm-12">
                                <label for="propertyLocation"><?php echo e(__('Property Location (Room No/Shop No.)')); ?></label>
                                <input id="propertyLocation" type="number" min="0" placeholder="Enter Room NO / Shop No " class="form-control<?php echo e($errors->has('propertyLocation') ? ' is-invalid' : ''); ?>" name="propertyLocation" value="<?php echo e($te->propertyLocation); ?>" >
                                <?php if($errors->has('propertyLocation')): ?>
                                    <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('propertyLocation')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-md-6 col-lg-6 col-sm-12">
                                <label for="propertySize"><?php echo e(__('Property Size')); ?></label>
                                <input id="propertySize" type="number" placeholder="Enter Property Size  (Sqr ft)" class="form-control<?php echo e($errors->has('propertySize') ? ' is-invalid' : ''); ?>" name="propertySize" value="<?php echo e($te->propertySize); ?>"  required>
                                <?php if($errors->has('propertySize')): ?>
                                    <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('propertySize')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="col-md-6 col-lg-6 col-sm-12">
                                <label for="jointProperty"><?php echo e(__('Joint Property')); ?></label>
                                <!-- <input id="jointProperty" type="text" placeholder="Enter Joint Property" class="form-control<?php echo e($errors->has('jointProperty') ? ' is-invalid' : ''); ?>" name="jointProperty" value="<?php echo e($PropertyJoint); ?>"  required> -->
                                <select class="form-control" name="jointProperty" id="jointProperty" >
                                    <option value="<?php echo e($PropertyJoint); ?>"><?php echo e($PropertyJoint); ?></option>
                                    <option value="Yes" disabled>Yes</option>
                                    <option value="No">No</option>
                                    
                                </select>
                                <?php if($errors->has('jointProperty')): ?>
                                    <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('jointProperty')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                       
                       
                    
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    &nbsp;&nbsp;
                    &nbsp;
                    <div><h3>Applicant Information</h3></div>
                    <hr>
                    <?php $__currentLoopData = $applicant; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $te): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                        <div class="form-group row">
                            <div class="col-md-12 col-lg-12 col-sm-12">
                                <img src="../storage/cover_images/<?php echo e($te->cover_image); ?>" height="100" width="100">
                                <br>
                                <label>Please update your Picture</label>
                                <br>
                                <input type="file" name="cover_image" id="cover_image" class="btn btn-primary" style="color:white;"/>
                                    <?php if($errors->has('cover_image')): ?>
                                        <span class="invalid-feedback">
                                            <strong><?php echo e($errors->first('cover_image')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                <br>
                            </div>
                        </div>

                        <div class="form-group row">
                            <div class="col-md-3 col-lg-3 col-sm-12">
                                <label for="name" ><?php echo e(__('Name of Applicant')); ?></label>
                                <input id="name" type="text" placeholder="Enter Name of Applicant " class="form-control<?php echo e($errors->has('title') ? ' is-invalid' : ''); ?>" name="name" value="<?php echo e($te->name); ?>" required>
                                
                                <?php if($errors->has('name')): ?>
                                    <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('name')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="col-md-3 col-lg-3 col-sm-12">
                                <label for="fatherName"><?php echo e(__('S/O,D/O,W/O')); ?></label>
                                <input id="fatherName" type="text" placeholder="Enter father Name " class="form-control<?php echo e($errors->has('fatherName') ? ' is-invalid' : ''); ?>" name="fatherName" value="<?php echo e($te->fatherName); ?>" required>
                                <?php if($errors->has('fatherName')): ?>
                                    <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('fatherName')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        <!-- </div> -->
                        <!-- <div class="form-group row"> -->
                            <div class="col-md-3 col-lg-3 col-sm-12">
                                <label for="cnicNo"><?php echo e(__('CNIC Number')); ?></label>
                                <input id="cnicNo" type="tel" size="15" maxlength="15" placeholder="e.g xxxxx-xxxxxxx-x" class="form-control<?php echo e($errors->has('cnicNo') ? ' is-invalid' : ''); ?>" name="cnicNo" value="<?php echo e($te->cnicNo); ?>" pattern="[0-9]{13}" title=" Please match the CNIC No" required>
                                <?php if($errors->has('cnicNo')): ?>
                                    <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('cnicNo')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="col-md-3 col-lg-3 col-sm-12">
                                <label for="passportNo"><?php echo e(__('Passport No')); ?></label>
                                <input id="passportNo" type="tel" size="8" maxlength="8" placeholder="e.g ab123456" class="form-control<?php echo e($errors->has('passportNo') ? ' is-invalid' : ''); ?>" name="passportNo" value="<?php echo e($te->passportNo); ?>" >
                                <?php if($errors->has('passportNo')): ?>
                                    <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('passportNo')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-md-12 col-lg-12 col-sm-12">
                                <label for="mailingAddress"><?php echo e(__('Mailing Address')); ?></label>
                                <input id="mailingAddress" type="text" placeholder="Enter Mailing Address " class="form-control<?php echo e($errors->has('mailingAddress') ? ' is-invalid' : ''); ?>" name="mailingAddress" value="<?php echo e($te->mailingAddress); ?>"  required>
                                <?php if($errors->has('mailingAddress')): ?>
                                    <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('mailingAddress')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-md-12 col-lg-12 col-sm-12">
                                <label for="permanentAddress"><?php echo e(__('Permanent Address')); ?></label>
                                <input id="permanentAddress" type="text" placeholder="Enter Permanent Address " class="form-control<?php echo e($errors->has('permanentAddress') ? ' is-invalid' : ''); ?>" name="permanentAddress" value="<?php echo e($te->permanentAddress); ?>"  required>
                                <?php if($errors->has('permanentAddress')): ?>
                                    <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('permanentAddress')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-md-3 col-lg-3 col-sm-12">
                                <label for="email"><?php echo e(__('Email')); ?></label>
                                <input id="email" type="email" placeholder="Enter Email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e($te->email); ?>"  >
                                <?php if($errors->has('email')): ?>
                                    <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="col-md-3 col-lg-3 col-sm-12">
                                <label for="phoneNO"><?php echo e(__('Phone Number')); ?></label>
                                <input id="phoneNO" type="tel" size="11" maxlength="11" placeholder="e.g xxx-xxxxxxx" class="form-control<?php echo e($errors->has('phoneNO') ? ' is-invalid' : ''); ?>" name="phoneNO" value="<?php echo e($te->phoneNO); ?>"  >
                                <?php if($errors->has('phoneNo')): ?>
                                    <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('phoneNo')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        <!-- </div> -->
                        <!-- <div class="form-group row"> -->
                            <div class="col-md-3 col-lg-3 col-sm-12">
                                <label for="mobileNo1"><?php echo e(__('Mobile Number')); ?></label>
                                <input id="mobileNo1" type="tel" size="12" maxlength="12" placeholder="e.g 0xxx-xxxxxxx" class="form-control<?php echo e($errors->has('mobileNo1') ? ' is-invalid' : ''); ?>" name="mobileNo1" value="<?php echo e($te->mobileNo1); ?>" pattern="[0-9]{11}" title=" Please match the Mobile No" required>
                                <?php if($errors->has('mobileNo1')): ?>
                                    <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('mobileNo1')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="col-md-3 col-lg-3 col-sm-12">
                                <label for="mobileNo2"><?php echo e(__('Mobile Number (2)')); ?></label>
                                <input id="mobileNo2" type="tel" size="12" maxlength="12" placeholder="e.g xxxx-xxxxxxx" class="form-control<?php echo e($errors->has('mobileNo2') ? ' is-invalid' : ''); ?>" name="mobileNo2" value="<?php echo e($te->mobileNo2); ?>"  >
                                <?php if($errors->has('mobileNo2')): ?>
                                    <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('mobileNo2')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <!--------------- Nominee information ----------------------------------------------------- -->

                        <!-- <div class="card-header" style="background:#f44336;color:white;margin:10px;">Nominee Registion Form</div> -->
                        &nbsp;&nbsp;&nbsp;
                        <div><h3>Nominee Information</h3></div>
                        <hr>
                        <div class="form-group row">
                            <div class="col-md-3 col-lg-3 col-sm-12">
                                <label for="nomineeName" ><?php echo e(__('Nominee Name')); ?></label>
                                <input id="nomineeName" type="text" placeholder="Enter Mominee Name  " class="form-control<?php echo e($errors->has('nomineeName') ? ' is-invalid' : ''); ?>" name="nomineeName" value="<?php echo e($te->nomineeName); ?>" required>
                                
                                <?php if($errors->has('nomineeName')): ?>
                                    <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('nomineeName')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="col-md-3 col-lg-3 col-sm-12">
                                <label for="nomineeFatherName"><?php echo e(__('S/O,D/O,W/O')); ?></label>
                                <input id="nomineeFatherName" type="text" placeholder="Enter father Name " class="form-control<?php echo e($errors->has('nomineeFatherName') ? ' is-invalid' : ''); ?>" name="nomineeFatherName" value="<?php echo e($te->nomineeFatherName); ?>" required>
                                <?php if($errors->has('nomineeFatherName')): ?>
                                    <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('nomineeFatherName')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        <!-- </div> -->
                        <!-- <div class="form-group row"> -->
                            <div class="col-md-3 col-lg-3 col-sm-12">
                                <label for="nomineeCnicNo"><?php echo e(__('Nominee CNIC Number')); ?></label>
                                <input id="nomineeCnicNo" type="tel" size="15" maxlength="15" placeholder="e.g xxxxx-xxxxxxx-x" class="form-control<?php echo e($errors->has('nomineeCnicNo') ? ' is-invalid' : ''); ?>" name="nomineeCnicNo" value="<?php echo e($te->nomineeCnicNo); ?>" pattern="[0-9]{13}" title=" Please match the CNIC No" required>
                                <?php if($errors->has('nomineeCnicNo')): ?>
                                    <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('nomineeCnicNo')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="col-md-3 col-lg-3 col-sm-12">
                                <label for="nomineePassportNo"><?php echo e(__('Passport No')); ?></label>
                                <input id="nomineePassportNo" type="tel" size="8" maxlength="8" placeholder="e.g ab123456" class="form-control<?php echo e($errors->has('nomineePassportNo') ? ' is-invalid' : ''); ?>" name="nomineePassportNo" value="<?php echo e($te->nomineePassportNo); ?>"  >
                                <?php if($errors->has('nomineePassportNo')): ?>
                                    <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('nomineePassportNo')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-md-12 col-lg-12 col-sm-12">
                                <label for="relationWithApplicant"><?php echo e(__('Relationship With applicant')); ?></label>
                                <input id="relationWithApplicant" type="text" placeholder="Enter Relation With Applicant " class="form-control<?php echo e($errors->has('relationWithApplicant') ? ' is-invalid' : ''); ?>" name="relationWithApplicant" value="<?php echo e($te->relationWithApplicant); ?>"  required>
                                <?php if($errors->has('relationWithApplicant')): ?>
                                    <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('relationWithApplicant')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-md-12 col-lg-12 col-sm-12">
                                <label for="nomineeMailingAddress"><?php echo e(__('Mailing Address')); ?></label>
                                <input id="nomineeMailingAddress" type="text" placeholder="Enter Mailing Address " class="form-control<?php echo e($errors->has('nomineeMailingAddress') ? ' is-invalid' : ''); ?>" name="nomineeMailingAddress" value="<?php echo e($te->nomineeMailingAddress); ?>"  >
                                <?php if($errors->has('nomineeMailingAddress')): ?>
                                    <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('nomineeMailingAddress')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <!-- <div class="form-group row">
                            <div class="col-md-12 col-lg-12 col-sm-12">
                                <label for="nomineePermanentAddress"><?php echo e(__('Permanent Address')); ?></label>
                                <input id="nomineePermanentAddress" type="text" placeholder="Enter Permanent Address " class="form-control<?php echo e($errors->has('nomineePermanentAddress') ? ' is-invalid' : ''); ?>" name="nomineePermanentAddress" value="<?php echo e($te->nomineePermanentAddress); ?>"  >
                                <?php if($errors->has('nomineePermanentAddress')): ?>
                                    <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('nomineePermanentAddress')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-md-3 col-lg-3 col-sm-12">
                                <label for="nomineeMail"><?php echo e(__('Email')); ?></label>
                                <input id="nomineeMail" type="text" placeholder="Enter Email" class="form-control<?php echo e($errors->has('nomineeMail') ? ' is-invalid' : ''); ?>" name="nomineeMail" value="<?php echo e($te->nomineeMail); ?>"  >
                                <?php if($errors->has('nomineeMail')): ?>
                                    <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('nomineeMail')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="col-md-3 col-lg-3 col-sm-12">
                                <label for="nomineePhoneNo"><?php echo e(__('Phone Number')); ?></label>
                                <input id="nomineePhoneNo" type="text" placeholder="Enter Phone No" class="form-control<?php echo e($errors->has('nomineePhoneNo') ? ' is-invalid' : ''); ?>" name="nomineePhoneNo" value="<?php echo e($te->nomineePhoneNo); ?>"  >
                                <?php if($errors->has('nomineePhoneNo')): ?>
                                    <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('nomineePhoneNo')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
            
                            <div class="col-md-3 col-lg-3 col-sm-12">
                                <label for="nomineeMobileNo1"><?php echo e(__('Mobile Number')); ?></label>
                                <input id="nomineeMobileNo1" type="text" placeholder="Enter Mobile number" class="form-control<?php echo e($errors->has('nomineeMobileNo1') ? ' is-invalid' : ''); ?>" name="nomineeMobileNo1" value="<?php echo e($te->nomineeMobileNo1); ?>"  >
                                <?php if($errors->has('nomineeMobileNo1')): ?>
                                    <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('nomineeMobileNo1')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="col-md-3 col-lg-3 col-sm-12">
                                <label for="nomineeMobileNo2"><?php echo e(__('Phone Number (2)')); ?></label>
                                <input id="nomineeMobileNo2" type="text" placeholder="Enter Mobile Numhber 2" class="form-control<?php echo e($errors->has('nomineeMobileNo2') ? ' is-invalid' : ''); ?>" name="nomineeMobileNo2" value="<?php echo e($te->nomineeMobileNo2); ?>"  >
                                <?php if($errors->has('nomineeMobileNo2')): ?>
                                    <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('nomineeMobileNo2')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div> -->
                       
                    <!-- </from> -->
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    &nbsp;&nbsp;&nbsp;&nbsp;
                    <div><h3>Payment Information</h3></div>
                        <hr>
                    <?php $__currentLoopData = $payment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $te): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                        <div class="form-group row">
                            <div class="col-md-6 col-lg-6 col-sm-12">
                                <label for="paymentType" ><?php echo e(__('Cash / Pay Order / Cheque / Adjustment')); ?></label>
                                <input id="paymentType" type="text" placeholder="Enter Property Payment Type " class="form-control<?php echo e($errors->has('paymentType') ? ' is-invalid' : ''); ?>" name="paymentType" value="<?php echo e($te->paymentType); ?>" required>
                                 
                                <?php if($errors->has('paymentType')): ?>
                                    <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('paymentType')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="col-md-6 col-lg-6 col-sm-12">
                                <label for="transferTo"><?php echo e(__('In Favor of')); ?></label>
                                <input id="transferTo" type="text" placeholder="transferTo " class="form-control<?php echo e($errors->has('transferTo') ? ' is-invalid' : ''); ?>" name="transferTo" value=" Montviro (Pvt) Ltd." required>
                              
                                <?php if($errors->has('transferTo')): ?>
                                    <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('transferTo')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-md-12 col-lg-12 col-sm-12">
                                <label for="bankName"><?php echo e(__('Bank Name')); ?></label>
                                <input id="bankName" type="text" placeholder="Enter bankName " class="form-control<?php echo e($errors->has('bankName') ? ' is-invalid' : ''); ?>" name="bankName" value="<?php echo e($te->bankName); ?>" >
                               
                                <?php if($errors->has('bankName')): ?>
                                    <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('bankName')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                           
                        </div>
                        <div class="form-group row">
                            <div class="col-md-6 col-lg-6 col-sm-12">
                                <label for="propertyPurchingDate"><?php echo e(__('Date')); ?></label>
                                <input id="propertyPurchingDate" type="text" placeholder="Enter Date (yyyy-mm-dd) " class="form-control<?php echo e($errors->has('propertyPurchingDate') ? ' is-invalid' : ''); ?>" name="propertyPurchingDate" value="<?php echo e($te->propertyPurchingDate); ?>" >
                                <?php if($errors->has('propertyPurchingDate')): ?>
                                    <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('propertyPurchingDate')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="col-md-6 col-lg-6 col-sm-12">
                                <label for="propertyPrice"><?php echo e(__('Total Amount')); ?></label>
                                <input id="propertyPrice" type="text" placeholder="Enter Total Amount " class="form-control<?php echo e($errors->has('propertyPrice') ? ' is-invalid' : ''); ?>" name="propertyPrice" value="<?php echo e($te->propertyPrice); ?>" required>
                                <?php if($errors->has('propertyPrice')): ?>
                                    <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('propertyPrice')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-md-12 col-lg-12 col-sm-12">
                                <label for="propertyPaymentProcedure"><?php echo e(__('property Payment Procedure')); ?></label>
                                <!-- <input id="propertyPaymentProcedure" type="text" placeholder="Enter Total Amount " class="form-control<?php echo e($errors->has('propertyPaymentProcedure') ? ' is-invalid' : ''); ?>" name="propertyPaymentProcedure" value="<?php echo e($te->propertyPaymentProcedure); ?>" required> -->
                                <select class="form-control" name="propertyPaymentProcedure" id="propertyPaymentProcedure" onchange="paymentProcedure(this);">
                                    <option value="<?php echo e($te->propertyPaymentProcedure); ?>"><?php echo e($te->propertyPaymentProcedure); ?></option>
                                    <option value="Installment">Installment</option>
                                    <option value="Total Amount">Total Amount</option>
                                    
                                </select>
                                <?php if($errors->has('propertyPaymentProcedure')): ?>
                                    <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('propertyPaymentProcedure')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div id="addtoken" style="display:inline;">
                        <div><h3>Token Information</h3></div>
                        <?php $__currentLoopData = $token; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $te): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="form-group row">
                            <div class="col-md-6 col-lg-6 col-sm-12" >
                                <label id="tokenPayment" for="tokenPayment" >Token Payment</label>
                                <input id="tokenPayment" type="number" min="0" placeholder="Enter Token payment" class="form-control" name="tokenPayment" value="<?php echo e($te->tokenPayment); ?>" style="border: 1px solid red;">
                              
                            </div>       
                            <div class="col-md-6 col-lg-6 col-sm-12">
                                <label for="remaningPaymentDate">Remaning Payment Date</label>
                                <input id="remaningPaymentDate" type="Date" placeholder="Enter Remaning Payment Date" class="form-control" name="remaningPaymentDate" value="<?php echo e($te->remaningPaymentDate); ?>" style="border: 1px solid red;">
                               
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        &nbsp;&nbsp;
                            <div id="addinstallment" style="display:inline;">
                            
                            </div>
                        
                        <!-- <div class="card-header" style="background:#f44336;color:white;margin:10px;">Witness Form</div> -->
                        &nbsp;&nbsp;&nbsp;&nbsp;
                        <div><h3>Seller Information</h3></div>
                        <hr>
                      
                        <div class="form-group row">    
                            <div class="col-md-12 col-lg-12 col-sm-12">
                                    <label for="witnessName"><?php echo e(__('Saller Name')); ?></label>
                                    <select class="form-control" name="propertySellerId" id="propertySellerId" >
                                        <option value="<?php echo e($id); ?>"><?php echo e($sname); ?></option>
                                        <?php $__currentLoopData = $seller; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $te): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                               
                                                <option value="<?php echo e($te->id); ?>"><?php echo e($te->sallerName); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select> 
                            </div>
                          
                        </div>
                        
                        <!-- <div class="card-header" style="background:#f44336;color:white;margin:10px;">Review Form</div> -->
                        &nbsp;&nbsp;&nbsp;&nbsp;
                        <div><h3>Review</h3></div>
                        <hr>
                        <?php $__currentLoopData = $review; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $te): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="form-group row">   
                            <div class="col-md-12 col-lg-12 col-sm-12">
                                <label for="comment"><?php echo e(__('Write your Comments')); ?></label>
                                <!-- <input  type="text"  placeholder="Enter comment" class="form-control<?php echo e($errors->has('comment') ? ' is-invalid' : ''); ?>" name="comment" value="<?php echo e(old('comment')); ?>" > -->
                                <textarea rows="4" cols="100" id="comment" name="comment" placeholder="Enter your comment" class="form-control<?php echo e($errors->has('comment') ? ' is-invalid' : ''); ?>" name="comment" ><?php echo e($te->comment); ?></textarea>
                                <?php if($errors->has('comment')): ?>
                                    <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('comment')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div> 
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <!-- <input type="hidden" name="propertyId" value=""> -->
                        <div class="col-md-12 col-lg-12 col-sm-12" style="margin-top:30px;">
                            <div class="form-group row mb-0">
                                <div class="col-md-12 ">
                                    <button type="submit" class="btn btn-lg " style="float:right; background-color:#f44336 !important; color:white;" >
                                        <?php echo e(__('Update')); ?>

                                    </button>
                                </div>
                            </div>
                        </div>
                   
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </from>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- script fucntion -->
<script>
//add fucntion to test
function paymentProcedure(val){

    
    var paymentProcedure = val.value;
    var parent = document.getElementById('addinstallment');
    if( paymentProcedure == "Installment"){
        
        document.getElementById("addtoken").style.display ="none";
       
        var added = '<div><h3>Installment Information</h3></div>'+
                        '<div class="form-group row">'+
                            '<div class="col-md-6 col-lg-6 col-sm-12">'+
                                '<label for="noOfInstallments" >No Of installment</label>'+
                              
                                  '<select class="form-control" name="noOfInstallments" id="noOfInstallments" >'+
                                    '<option value="">Select No of Installments</option>'+
                                    '<option value="1">1</option>'+
                                    '<option value="2">2</option>'+
                                    '<option value="3">3</option>'+
                                    '<option value="4">4</option>'+
                                    '<option value="5">5</option>'+
                                    '<option value="6">6</option>'+
                                    '<option value="7">7</option>'+
                                    '<option value="8">8</option>'+
                                    '<option value="9">9</option>'+
                                    '<option value="10">10</option>'+
                                    
                                '</select>'+
                              
                            '</div>'+       
                            '<div class="col-md-6 col-lg-6 col-sm-12">'+
                                '<label for="downpayment">Down Payment</label>'+
                                '<input id="downpayment" type="number" min="0" placeholder="Enter down payment" class="form-control" name="downpayment" value="" >'+
                               
                            '</div>'+
                        '</div>'+
                    '</div>';              
                        
        parent.insertAdjacentHTML('beforeend', added);
    }
    if(paymentProcedure == "Total Amount"){

        document.getElementById("addtoken").style.display ="none";
        document.getElementById("addinstallment").style.display ="none";
    }
    
    return 0;
}


    </script>
<!-- End script funtion -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>