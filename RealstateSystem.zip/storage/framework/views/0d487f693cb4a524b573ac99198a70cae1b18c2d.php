<?php $__env->startSection('content'); ?>

<div class="container" style="margin-top:60px;">
    <div class="row justify-content-center">
        <div class="col-md-9 col-lg-9 col-sm-12 col-xs-12 offset-md-3 offset-lg-3">
        <?php echo $__env->make('flash-message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <div>
            <button class="btn btn-lg btn-default" onclick="window.history.go(-1)">Back</button>
            <a href="<?php echo e(url('sellerinfos')); ?>" class="btn btn-lg btn-primary " style="float: right; background-color:#f44336 !important; color:white;">View All Seller</a>
        </div> 
        <br>
        <hr>    
        
            <div class="card">
                <div class="card-header" style="background-color: #f44336;color:white;"> Seller Editing Form </div>

                <div class="card-body">
                    <div><h3> Editing Seller Information</h3></div>
                    <hr>
                    &nbsp;&nbsp;
                    &nbsp;
                    <?php 
                    // var_dump($seller);
                    // echo "<br>";
                    // echo $seller['id'];
                    // foreach($seller as $te){
                    //     echo $te[0]['id'];
                    // }
                        // exit();
                         
                    ?>
                    <form method="POST"  action="<?php echo e(url('sellerupdate/'.$seller['id'])); ?>" enctype="multipart/form-data" value="PATCH">
                        <?php echo e(csrf_field()); ?>


                        <div class="form-group row">
                            <div class="col-md-6 col-lg-6 col-sm-12">
                                <label for="propertyAddress"><?php echo e(__('Seller Name')); ?></label>
                                <input id="sallerName" type="text" placeholder="Enter Seller Name " class="form-control<?php echo e($errors->has('sellerName') ? ' is-invalid' : ''); ?>" name="sallerName" value="<?php echo e($seller['sallerName']); ?>" required>
                                <?php if($errors->has('sallerName')): ?>
                                    <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('sallerName')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="col-md-6 col-lg-6 col-sm-12">
                                <label for="sellerFatherName"><?php echo e(__('Seller Father Name')); ?></label>
                                <input id="sellerFatherName" type="text" placeholder="Enter Seller's Father Name" class="form-control<?php echo e($errors->has('sellerFatherName') ? ' is-invalid' : ''); ?>" name="sallerFatherName" value="<?php echo e($seller['sallerFatherName']); ?>" required>
                                <?php if($errors->has('sellerFatherName')): ?>
                                    <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('sellerFatherName')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-md-6 col-lg-6 col-sm-12">
                                <label for="sallerDesignation"><?php echo e(__('Saller Designation')); ?></label>
                                <input id="sallerDesignation" type="text" placeholder="Enter Saller Designation" class="form-control<?php echo e($errors->has('sallerDesignation') ? ' is-invalid' : ''); ?>" name="sallerDesignation" value="<?php echo e($seller['sallerDesignation']); ?>" required>
                                <?php if($errors->has('sallerDesignation')): ?>
                                    <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('sallerDesignation')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="col-md-6 col-lg-6 col-sm-12">
                                <label for="sallerCnicNo"><?php echo e(__('Saller CNIC NO')); ?></label>
                                <input id="sallerCnicNo" type="text" placeholder="Enter saller CNIC NO" class="form-control<?php echo e($errors->has('sallerCnicNo') ? ' is-invalid' : ''); ?>" name="sallerCnicNo" value="<?php echo e($seller['sallerCnicNo']); ?>"  required>
                               
                                <?php if($errors->has('sallerCnicNo')): ?>
                                    <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('sallerCnicNo')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-md-12 col-lg-12 col-sm-12">
                                <label for="sallerAddress"><?php echo e(__('Saller Address')); ?></label>
                                <input id="sallerAddress" type="text" placeholder="Enter saller Address" class="form-control<?php echo e($errors->has('sallerAddress') ? ' is-invalid' : ''); ?>" name="sallerAddress" value="<?php echo e($seller['sallerAddress']); ?>"  >
                               
                                <?php if($errors->has('jointProperty')): ?>
                                    <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('jointProperty')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="col-md-12 col-lg-12 col-sm-12" style="margin-top:30px;">
                            <div class="form-group row mb-0">
                                <div class="col-md-12 ">
                                    <button type="submit" class="btn btn-lg " style="float:right; background-color:#f44336 !important; color:white;" >
                                        <?php echo e(__('Submit')); ?>

                                    </button>
                                </div>
                            </div>
                        </div>
                    </from>
                </div>
            </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>