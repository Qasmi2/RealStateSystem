<?php echo $__env->make('flash', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('content'); ?>
<div class="container" style="margin-top:60px;">
    <div class="row justify-content-center">
        <div class="col-md-10 col-lg-10 col-sm-12 col-xs-12 offset-md-3 offset-lg-3">
            <div class="card">
                <div class="card-header" style="background-color: #f44336;color:white;">Installment From</div>
<!-- <div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Property Registion Form</div> -->

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    <form method="POST"  action="<?php echo e(route('installments')); ?>" enctype="multipart/form-data" value="PATCH">
                        <?php echo e(csrf_field()); ?>

                        <div class="form-group row">
                            <div class="col-md-6 col-lg-6 col-sm-12">
                                <label for="noOfInstallments" ><?php echo e(__('Number of Installments')); ?></label>
                              
                                  <select class="form-control" name="noOfInstallments" id="noOfInstallments" >
                                    <option value="">Select No of Installments</option>
                                    <option value="1">1</option>
                                    <option value="2">2</option>
                                    <option value="3">3</option>
                                    <option value="4">4</option>
                                    <option value="5">5</option>
                                    <option value="6">6</option>
                                    <option value="7">7</option>
                                    <option value="8">8</option>
                                    <option value="9">9</option>
                                    <option value="10">10</option>
                                    
                                </select>
                                <?php if($errors->has('noOfInstallments')): ?>
                                    <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('noOfInstallments')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>       
                            <div class="col-md-6 col-lg-6 col-sm-12">
                                <label for="downpayment"><?php echo e(__('Down Payment')); ?></label>
                                <input id="downpayment" type="number" min="0" placeholder="Enter down payment" class="form-control<?php echo e($errors->has('downpayment') ? ' is-invalid' : ''); ?>" name="downpayment" value="<?php echo e(old('downpayment')); ?>" >
                                <?php if($errors->has('downpayment')): ?>
                                    <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('downpayment')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>                    
                        </div>
                        <input type="hidden" name="propertyId" value="<?php echo e($lastId['propertyId']); ?>">
                        <input type="hidden" name="paymentId" value="<?php echo e($lastId['id']); ?>">
                        <div class="col-md-12 col-lg-12 col-sm-12" style="margin-top:30px;">
                            <div class="form-group row mb-0">
                                <div class="col-md-12 ">
                                    <button type="submit" class="btn btn-lg " style="float:right; background-color:#f44336 !important; color:white;" >
                                        <?php echo e(__('Next')); ?>

                                    </button>
                                </div>
                            </div>
                        </div>
                    </from>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>