<?php $__env->startSection('content'); ?>
<div class="container" style="margin-top:60px;">
    <div class="row justify-content-center">
        <div class="col-md-9 col-lg-9 col-sm-12 col-xs-12 offset-md-3 offset-lg-3">
        <?php echo $__env->make('flash-message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        <script>
                                $(document).ready(function() {
                                $('a[data-confirm]').click(function(ev) {
                                var href = $(this).attr('href');
                                if (!$('#dataConfirmModal').length) {
                                $('body').append('<div id="dataConfirmModal" class="modal fade modal" role="dialog" aria-labelledby="dataConfirmLabel" aria-hidden="true"><div class="modal-dialog "><div class="modal-content"><div class=" modal-header" style="text-align:center;display:flow-root !important;color:white;background-color: red;" ><button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button><h3 id="dataConfirmLabel" >Please Confirm</h3></div><div class="modal-body"></div><div class="modal-footer"><button class="btn" data-dismiss="modal" aria-hidden="true">Cancel</button><a class="btn btn-danger" id="dataConfirmOK">Delete</a></div></div></div></div>');
                                } 
                                $('#dataConfirmModal').find('.modal-body').text($(this).attr('data-confirm'));
                                $('#dataConfirmOK').attr('href', href);
                                $('#dataConfirmModal').modal({show:true});
                                return false;
                                    });
                            });
                        </script>
                        <!-- End JavaScript code -->
                <!-- <div class="card-body"> -->
                   
                    <?php  $applicant = array($applicant);
                           
                           $property = array($property);
                           foreach($property as $key){
                            $Idkey = $key->id;
                            $sellerId = $key->propertySellerId;
                            }
                          
                           $payment = array($payment);
                            // $seller = array($seller);
                           $review = array($review);
                           foreach($seller as $te){
                               if( $te->id == $sellerId)
                               {
                                   $sname =  $te->sallerName; 
                                   $sfatherName =  $te->sallerFatherName;
                                   $sdesignation = $te->sallerDesignation;
                                   $scnicNo = $te->sallerCnicNo;
                                   
                               }
                              

                           }
                          
                    ?>
                  
                     <div>
                        <button class="btn btn-lg btn-default" onclick="window.history.go(-1)">Back</button>
                        <button style="float:right;color:white;" class="btn btn-lg btn-warning" ><a href="<?php echo e(url('editingform/'.$Idkey)); ?>">Edit</a></button>
                        <!-- <button style="float:right;color:white;" class="btn btn-lg btn-danger" data-confirm="Are you sure you want to delete?"><a href="<?php echo e(url('deleteform/'.$Idkey)); ?>">Delete</a></button> -->
                        <a href="<?php echo e(url('deleteform/'.$Idkey)); ?>" data-confirm="Are you sure you want to delete?" class="btn btn-lg btn-danger ">Delete</a>
                    </div> 

                    <fieldset class="col-md-12" style="background-color:#fff; margin-top:20px;">    	
                    <legend>Registration Detail</legend>
                        <!-- <div class="col-md-12 col-lg-12 col-sm-12">     -->
                            <div class="form-group row">
                                <div class="col-md-6">
                        <?php $__currentLoopData = $property; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $te): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="p-3 bg-secondary mb-2">  <label for="title" style="margin-top: 5px;margin-left: 10px;"><?php echo e(__('Form Regisration Number')); ?>    :</label>
                                               
                                        </div>
                                        <br>
                                        <div class="p-3 bg-secondary mb-2"> <label for="title" style="margin-top: 5px;margin-left: 10px;"><?php echo e(__('Registered Project')); ?>    :</label>
                                               <b><?php echo e($te->propertyType); ?></b> 
                                        </div>
                                        <br>
                                        <div class="p-3 bg-secondary mb-2 "> <label for="title" style="margin-top: 5px;margin-left: 10px;"><?php echo e(__('Registion Status')); ?>   :</label>
                                            <b><?php echo e($te->registrationStatus); ?></b>
                                        </div>
                                </div>
                                <div class="col-md-6">   
                                       
                                       
                                        <div class="p-3 bg-secondary mb-2"> <label for="title" style="margin-top: 5px;margin-left: 10px;"><?php echo e(__('Property Address (Floor NO.)')); ?>    :</label>
                                               <b><?php echo e($te->propertyAddress); ?></b>
                                        </div>
                                        <br>
                                        <div class="p-3 bg-secondary mb-2 "> <label for="title" style="margin-top: 5px;margin-left: 10px;"><?php echo e(__('Property Location (ROOM NO. / SHOP NO.')); ?>    :</label>
                                            <b> <?php echo e($te->propertyLocation); ?></b>
                                        </div>
                                        <br>
                                        <div class="p-3 bg-secondary mb-2 "> <label for="title" style="margin-top: 5px;margin-left: 10px;"><?php echo e(__('Property Size')); ?>    :</label>
                                            <b> <?php echo e($te->propertySize); ?></b>
                                        </div>
                                </div>            
        
                            </div>
                                    
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </fieldset>
                    <fieldset class="col-md-12" style="background-color:#fff; margin-top:20px;">    	
                    <legend>Personal Information</legend>
                        <div class="form-group row">
                            <div class="col-md-6">
                            <?php $__currentLoopData = $applicant; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $te): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                                        <div class="p-3 bg-secondary mb-2">  <label for="title" style="margin-top: 5px;margin-left: 10px;"><?php echo e(__('Picture')); ?>    :</label>
                                                <img src="../storage/cover_images/<?php echo e($te->cover_image); ?>" height="100" width="100">
                                        </div>
                                        <div class="p-3 bg-secondary mb-2">  <label for="title" style="margin-top: 5px;margin-left: 10px;"><?php echo e(__('Name')); ?>    :</label>
                                                <b><?php echo e($te->name); ?></b> 
                                        </div>
                                        <br>
                                        <div class="p-3 bg-secondary mb-2"> <label for="title" style="margin-top: 5px;margin-left: 10px;"><?php echo e(__('Father Name')); ?>    :</label>
                                               <b><?php echo e($te->fatherName); ?></b> 
                                        </div>
                                        <br>
                                        <div class="p-3 bg-secondary  mb-2 "> <label for="title" style="margin-top: 5px;margin-left: 10px;"><?php echo e(__('CNIC NO.')); ?>   :</label>
                                            <b><?php echo e($te->cnicNo); ?></b>
                                        </div>
                                        <br>
                                        <div class="p-3 bg-secondary  mb-2 "> <label for="title" style="margin-top: 5px;margin-left: 10px;"><?php echo e(__('Mailing Address')); ?>   :</label>
                                            <b><?php echo e($te->mailingAddress); ?></b>
                                        </div>
                                        <br>
                                        <div class="p-3 bg-secondary mb-2 "> <label for="title" style="margin-top: 5px;margin-left: 10px;"><?php echo e(__('Permanent Address')); ?>   :</label>
                                            <b><?php echo e($te->permanentAddress); ?></b>
                                        </div>
                            </div>
                                <div class="col-md-6">   

                                        <div class="p-3 bg-secondary  mb-2 "> <label for="title" style="margin-top: 5px;margin-left: 10px;"><?php echo e(__('Passport No. ')); ?>   :</label>
                                            <b><?php echo e($te->passportNo); ?></b>
                                        </div>
                                        <br>
                                        <div class="p-3 bg-secondary mb-2"> <label for="title" style="margin-top: 5px;margin-left: 10px;"><?php echo e(__('Email')); ?>    :</label>
                                               <b><?php echo e($te->email); ?></b>
                                        </div>
                                        <br>
                                        <div class="p-3 bg-secondary mb-2 "> <label for="title" style="margin-top: 5px;margin-left: 10px;"><?php echo e(__('Phone NO.')); ?>    :</label>
                                            <b> <?php echo e($te->phoneNO); ?></b>
                                        </div>
                                        <br>
                                        <div class="p-3 bg-secondary mb-2 "> <label for="title" style="margin-top: 5px;margin-left: 10px;"><?php echo e(__('Mobile No. 1')); ?>    :</label>
                                            <b><?php echo e($te->mobileNo1); ?></b>
                                        </div>
                                        <br>
                                        <div class="p-3 bg-secondary mb-2 "> <label for="title" style="margin-top: 5px;margin-left: 10px;"><?php echo e(__('Mobile No. 2 ')); ?>   :</label>
                                            <b><?php echo e($te->mobileNo2); ?></b>
                                        </div>
                                        
                                        
                                </div>            
        
                            </div>
                                    
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </fieldset>
                    <fieldset class="col-md-12" style="background-color:#fff; margin-top:20px;">    	
                    <legend>Nominee Information</legend>
                        <div class="form-group row">
                            <div class="col-md-6">
                            <?php $__currentLoopData = $applicant; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $te): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="p-3 bg-secondary mb-2">  <label for="title" style="margin-top: 5px;margin-left: 10px;"><?php echo e(__('Name')); ?>    :</label>
                                                <b><?php echo e($te->nomineeName); ?></b> 
                                        </div>
                                        <br>
                                        <div class="p-3 bg-secondary mb-2"> <label for="title" style="margin-top: 5px;margin-left: 10px;"><?php echo e(__('Father Name')); ?>    :</label>
                                               <b><?php echo e($te->nomineeFatherName); ?></b> 
                                        </div>
                                        <br>
                                        <div class="p-3 bg-secondary mb-2 "> <label for="title" style="margin-top: 5px;margin-left: 10px;"><?php echo e(__('CNIC NO.')); ?>   :</label>
                                            <b><?php echo e($te->nomineeCnicNo); ?></b>
                                        </div>
                                        <br>
                                        <div class="p-3 bg-secondary mb-2 "> <label for="title" style="margin-top: 5px;margin-left: 10px;"><?php echo e(__('Mailing Address')); ?>   :</label>
                                            <b><?php echo e($te->nomineeMailingAddress); ?></b>
                                        </div>
                                        <br>
                                        <div class="p-3 bg-secondary mb-2 "> <label for="title" style="margin-top: 5px;margin-left: 10px;"><?php echo e(__('Permanent Address')); ?>   :</label>
                                            <b><?php echo e($te->nomineePermanentAddress); ?></b>
                                        </div>
                            </div>
                                <div class="col-md-6">   

                                        <div class="p-3 bg-secondary mb-2 "> <label for="title" style="margin-top: 5px;margin-left: 10px;"><?php echo e(__('Passport No. ')); ?>   :</label>
                                            <b><?php echo e($te->nomineePassportNo); ?></b>
                                        </div>
                                        <br>
                                        <div class="p-3 bg-secondary mb-2"> <label for="title" style="margin-top: 5px;margin-left: 10px;"><?php echo e(__('Email')); ?>    :</label>
                                               <b><?php echo e($te->nomineeMail); ?></b>
                                        </div>
                                        <br>
                                        <div class="p-3 bg-secondary mb-2 "> <label for="title" style="margin-top: 5px;margin-left: 10px;"><?php echo e(__('Phone NO.')); ?>    :</label>
                                            <b> <?php echo e($te->nomineePhoneNo); ?></b>
                                        </div>
                                        <br>
                                        <div class="p-3 bg-secondary mb-2 "> <label for="title" style="margin-top: 5px;margin-left: 10px;"><?php echo e(__('Mobile No. 1')); ?>    :</label>
                                            <b><?php echo e($te->nomineeMobileNo1); ?></b>
                                        </div>
                                        <br>
                                        <div class="p-3 bg-secondary mb-2 "> <label for="title" style="margin-top: 5px;margin-left: 10px;"><?php echo e(__('Mobile No. 2 ')); ?>   :</label>
                                            <b><?php echo e($te->nomineeMobileNo2); ?></b>
                                        </div>
                                        
                                        
                                </div>            
        
                            </div>
                                    
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </fieldset>
                    <fieldset class="col-md-12" style="background-color:#fff; margin-top:20px;">    	
                    <legend>Payment Infromation</legend>
                        <!-- <div class="col-md-12 col-lg-12 col-sm-12">     -->
                            <div class="form-group row">
                                <div class="col-md-6">
                            <?php $__currentLoopData = $payment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $te): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="p-3 bg-secondary mb-2">  <label for="title" style="margin-top: 5px;margin-left: 10px;"><?php echo e(__('Cash / Pay Order / Cheque / Adjustment')); ?>    :</label>
                                           <b><?php echo e($te->paymentType); ?></b>
                                        </div>
                                        <br>
                                        <div class="p-3 bg-secondary mb-2"> <label for="title" style="margin-top: 5px;margin-left: 10px;"><?php echo e(__('In Favor Of')); ?>    :</label>
                                               <b><?php echo e($te->transferTo); ?></b> 
                                        </div>
                                        <br>
                                        <div class="p-3 bg-secondary mb-2 "> <label for="title" style="margin-top: 5px;margin-left: 10px;"><?php echo e(__('Bank Name')); ?>   :</label>
                                            <b><?php echo e($te->bankName); ?></b>
                                        </div>
                                </div>
                                <div class="col-md-6">   
                                       
                                       
                                        <div class="p-3 bg-secondary mb-2"> <label for="title" style="margin-top: 5px;margin-left: 10px;"><?php echo e(__('Total Amount')); ?>    :</label>
                                               <b><?php echo e($te->propertyPrice); ?></b>
                                        </div>
                                        <br>
                                        <div class="p-3 bg-secondary mb-2 "> <label for="title" style="margin-top: 5px;margin-left: 10px;"><?php echo e(__('Date')); ?>    :</label>
                                            <b><?php echo e($te->propertyPurchingDate); ?></b>
                                        </div>
                                        <br>
                                        <div class="p-3 bg-secondary mb-2 "> <label for="title" style="margin-top: 5px;margin-left: 10px;"><?php echo e(__('Total Payment / Installment')); ?>    :</label>
                                            <b> <?php echo e($te->propertyPaymentProcedure); ?></b>
                                        </div>
                                </div>            
        
                            </div>
                                    
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </fieldset>
                    <fieldset class="col-md-12" style="background-color:#fff; margin-top:20px;">    	
                    <legend>Seller  Infromation</legend>
                        <!-- <div class="col-md-12 col-lg-12 col-sm-12">     -->
                            <div class="form-group row">
                                <div class="col-md-6">
                           
                                        <div class="p-3 bg-secondary mb-2">  <label for="title" style="margin-top: 5px;margin-left: 10px;"><?php echo e(__('Seller Name')); ?>    :</label>
                                           <b><?php echo e($sname); ?></b>
                                        </div>
                                </div>
                                <div class="col-md-6">
                                        <div class="p-3 bg-secondary mb-2"> <label for="title" style="margin-top: 5px;margin-left: 10px;"><?php echo e(__('Seller CNIC NO ')); ?>    :</label>
                                               <b><?php echo e($sfatherName); ?></b> 
                                        </div>
                                        
                                </div>
                                        
                            </div>
                                    
                       
                    </fieldset>
                    <fieldset class="col-md-12" style="background-color:#fff; margin-top:20px;">    	
                    <legend>Review</legend>
                        <!-- <div class="col-md-12 col-lg-12 col-sm-12">     -->
                            <div class="form-group row">
                                <div class="col-md-12">
                            <?php $__currentLoopData = $review; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $te): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="p-3 bg-secondary mb-2">  <label for="title" style="margin-top: 5px;margin-left: 10px;"><?php echo e(__('Your Comment')); ?>    :</label>
                                           <b><br><?php echo e($te->comment); ?></b>
                                        </div>
                                </div>
                                        
                            </div>
                                    
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </fieldset>
                    <div>
                        <button class="btn btn-lg btn-default" onclick="window.history.go(-1)">Back</button>
                        <button style="float:right;color:white;" class="btn btn-lg btn-warning" ><a href="<?php echo e(url('editingform/'.$Idkey)); ?>">Edit</a></button>
                        <!-- <button style="float:right;color:white;" class="btn btn-lg btn-danger" data-confirm="Are you sure you want to delete?"><a href="<?php echo e(url('deleteform/'.$Idkey)); ?>">Delete</a></button> -->
                        <a href="<?php echo e(url('deleteform/'.$Idkey)); ?>" data-confirm="Are you sure you want to delete?" class="btn btn-lg btn-danger">Delete</a>
                    </div> 
                      
                <!-- </div>
            </div> -->
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>