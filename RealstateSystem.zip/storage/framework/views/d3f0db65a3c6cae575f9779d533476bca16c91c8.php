<?php $__env->startSection('content'); ?>

<?php 
  $numberOfSellers = sizeof($seller);

?>
<div class="container" style="margin-top:60px;">
    <div class="row justify-content-center">
        <div class="col-md-9 col-lg-9 col-sm-12 col-xs-12 offset-md-3 offset-lg-3">
        <?php echo $__env->make('flash-message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <div class="card">
                <div class="card-header" style="background-color: #f44336;color:white;"> Registion Form </div>

                <div class="card-body">
                   
                    <div><h3>Property Information</h3></div>
                    <hr>
                    &nbsp;&nbsp;
                    &nbsp;
                    
                    <form method="POST"  action="<?php echo e(url('allformdata')); ?>" enctype="multipart/form-data" value="PATCH">
                        <?php echo e(csrf_field()); ?>

                        <div class="form-group row">
                            <div class="col-md-4 col-lg-4 col-sm-12">
                                <label for="propertyType" ><?php echo e(__('Registion Project')); ?> </label>
                               
                                <select class="form-control" name="propertyType" id="propertyType" >
                                    <option value="">Select Title</option>
                                    <option value="Montviro Hotel">Montviro Hotel</option>
                                    <option value="Montviro Mall">Montviro Mall</option>
                                    <option value="Montviro Theme Park">Montviro Theme Park</option>
                                </select>
                                <?php if($errors->has('propertyType')): ?>
                                    <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('propertyType')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="col-md-4 col-lg-4 col-sm-12">
                                <label for="registrationStatus"><?php echo e(__('Registration Status')); ?> </label>
                               
                                <select class="form-control" name="registrationStatus" id="registrationStatus" >
                                    <option value="">choice Projecty Status</option>
                                    <option value="First Alottee">First Alottee</option>
                                    <option value="Transfer Certificate">Transfer Certificate</option>
                                    <option value="Open Certificate">Open Certificate</option>
                                </select>
                                <?php if($errors->has('registrationStatus')): ?>
                                    <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('registrationStatus')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        <!-- </div>
                        <div class="form-group row"> -->
                            <div class="col-md-4 col-lg-4 col-sm-12">
                                <label for="propertySection"><?php echo e(__('Property Section')); ?> </label>
                              
                                <select class="form-control" name="propertySection" id="propertySection" >
                                    <option value="">Choice the Selection</option>
                                    <option value="Office">Office</option>
                                    <option value="Shop">Shop</option>
                                    <option value="Suite">Suite</option>
                                    <option value="Food Court">Food Court</option>
                                    <option value="Kiosk">Kiosk</option>
                                    <option value="Theme Park">Theme Park</option>
                                </select>
                                <?php if($errors->has('propertySection')): ?>
                                    <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('propertySection')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                           
                        </div>
                        <div class="form-group row">
                            <div class="col-md-6 col-lg-6 col-sm-12">
                                <label for="propertyAddress"><?php echo e(__('Property Address ( Floor No.)')); ?></label>
                                <input id="Property Address" type="number" min="0" placeholder="Enter Floor No, " class="form-control<?php echo e($errors->has('propertyAddress') ? ' is-invalid' : ''); ?>" name="propertyAddress" value="" >
                                <?php if($errors->has('propertyAddress')): ?>
                                    <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('propertyAddress')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        <!-- </div> -->
                        <!-- <div class="form-group row"> -->
                            <div class="col-md-6 col-lg-6 col-sm-12">
                                <label for="propertyLocation"><?php echo e(__('Property Location (Room No/Shop No.)')); ?></label>
                                <input id="propertyLocation" type="number" min="0" placeholder="Enter Property Location (Room No / Shop NO) " class="form-control<?php echo e($errors->has('propertyLocation') ? ' is-invalid' : ''); ?>" name="propertyLocation" value="" >
                                <?php if($errors->has('propertyLocation')): ?>
                                    <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('propertyLocation')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-md-6 col-lg-6 col-sm-12">
                                <label for="propertySize"><?php echo e(__('Property Size')); ?></label>
                                <input id="propertySize" type="number" placeholder="Enter Property Size  (Sqr ft)" class="form-control<?php echo e($errors->has('propertySize') ? ' is-invalid' : ''); ?>" name="propertySize" value=""  required>
                                <?php if($errors->has('propertySize')): ?>
                                    <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('propertySize')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="col-md-6 col-lg-6 col-sm-12">
                                <label for="jointProperty"><?php echo e(__('Joint Property')); ?></label>
                                <!-- <input id="jointProperty" type="text" placeholder="Enter Joint Property" class="form-control<?php echo e($errors->has('jointProperty') ? ' is-invalid' : ''); ?>" name="jointProperty" value=""  required> -->
                                <select class="form-control" name="jointProperty" id="jointProperty" >
                                    <option value="No">No</option>
                                    <option value="Yes" disabled>Yes</option>
                                </select>
                                <?php if($errors->has('jointProperty')): ?>
                                    <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('jointProperty')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                       
                    &nbsp;&nbsp;
                    &nbsp;
                    <div><h3>Applicant Information</h3></div>
                    <hr>
                    
                    
                        <div class="form-group row">
                            <div class="col-md-12 col-lg-12 col-sm-12">
                            
                            
                                <label>Please choose your Picture</label>
                                <br>
                                <input type="file" name="cover_image" id="cover_image" class="btn btn-danger" style="color:white;"/>
                                    <?php if($errors->has('cover_image')): ?>
                                        <span class="invalid-feedback">
                                            <strong><?php echo e($errors->first('cover_image')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                <br>
                            </div>
                        </div>

                        <div class="form-group row">
                            <div class="col-md-3 col-lg-3 col-sm-12">
                                <label for="name" ><?php echo e(__('Name of Applicant')); ?></label>
                                <input id="name" type="text" placeholder="Enter Name of Applicant " class="form-control<?php echo e($errors->has('title') ? ' is-invalid' : ''); ?>" name="name" value="" required>
                                
                                <?php if($errors->has('name')): ?>
                                    <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('name')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="col-md-3 col-lg-3 col-sm-12">
                                <label for="fatherName"><?php echo e(__('S/O,D/O,W/O')); ?></label>
                                <input id="fatherName" type="text" placeholder="Enter father Name " class="form-control<?php echo e($errors->has('fatherName') ? ' is-invalid' : ''); ?>" name="fatherName" value="" required>
                                <?php if($errors->has('fatherName')): ?>
                                    <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('fatherName')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        <!-- </div> -->
                        <!-- <div class="form-group row"> -->
                            <div class="col-md-3 col-lg-3 col-sm-12">
                                <label for="cnicNo"><?php echo e(__('CNIC Number')); ?></label>
                                <input id="cnicNo" type="tel" size="15" maxlength="15" placeholder="e.g 6110112345678" class="form-control<?php echo e($errors->has('cnicNo') ? ' is-invalid' : ''); ?>" name="cnicNo" value=""  pattern="[0-9]{13}" title=" Please match the CNIC No" required>
                              
                                <?php if($errors->has('cnicNo')): ?>
                                    <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('cnicNo')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="col-md-3 col-lg-3 col-sm-12">
                                <label for="passportNo"><?php echo e(__('Passport No')); ?> (Optional)</label>
                                <input id="passportNo" type="tel" size="8" maxlength="8" placeholder="e.g ab123456" class="form-control<?php echo e($errors->has('passportNo') ? ' is-invalid' : ''); ?>" name="passportNo" value=""  >
                                <?php if($errors->has('passportNo')): ?>
                                    <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('passportNo')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-md-12 col-lg-12 col-sm-12">
                                <label for="mailingAddress"><?php echo e(__('Mailing Address')); ?></label>
                                <input id="mailingAddress" type="text" placeholder="Enter Mailing Address " class="form-control<?php echo e($errors->has('mailingAddress') ? ' is-invalid' : ''); ?>" name="mailingAddress" value=""  required>
                                <?php if($errors->has('mailingAddress')): ?>
                                    <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('mailingAddress')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-md-12 col-lg-12 col-sm-12">
                                <label for="permanentAddress"><?php echo e(__('Permanent Address')); ?></label>
                                <input id="permanentAddress" type="text" placeholder="Enter Permanent Address " class="form-control<?php echo e($errors->has('permanentAddress') ? ' is-invalid' : ''); ?>" name="permanentAddress" value=""  required>
                                <?php if($errors->has('permanentAddress')): ?>
                                    <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('permanentAddress')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-md-3 col-lg-3 col-sm-12">
                                <label for="email"><?php echo e(__('Email')); ?> (Optional)</label>
                                <input id="email" type="email" placeholder="Enter Email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="" >
                                <?php if($errors->has('email')): ?>
                                    <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="col-md-3 col-lg-3 col-sm-12">
                                <label for="phoneNO"><?php echo e(__('Phone Number')); ?>(Optional)</label>
                                <input id="phoneNO" type="tel" size="11" maxlength="11" placeholder="e.g 051xxxxxxx" class="form-control<?php echo e($errors->has('phoneNO') ? ' is-invalid' : ''); ?>" name="phoneNO" value=""  >
                                <?php if($errors->has('phoneNo')): ?>
                                    <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('phoneNo')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        <!-- </div> -->
                        <!-- <div class="form-group row"> -->
                            <div class="col-md-3 col-lg-3 col-sm-12">
                                <label for="mobileNo1"><?php echo e(__('Mobile Number')); ?></label>
                                <input id="mobileNo1"type="tel" size="12" maxlength="12" placeholder="e.g 0333xxxxxxx" class="form-control<?php echo e($errors->has('mobileNo1') ? ' is-invalid' : ''); ?>" name="mobileNo1" value="" pattern="[0-9]{11}" title=" Please match the Mobile No"  required>
                                <?php if($errors->has('mobileNo1')): ?>
                                    <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('mobileNo1')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="col-md-3 col-lg-3 col-sm-12">
                                <label for="mobileNo2"><?php echo e(__('Mobile Number (Opt)')); ?></label>
                                <input id="mobileNo2"  type="tel" size="12" maxlength="12" placeholder="e.g 0305xxxxxxx" class="form-control<?php echo e($errors->has('mobileNo2') ? ' is-invalid' : ''); ?>" name="mobileNo2" value="" >
                                <?php if($errors->has('mobileNo2')): ?>
                                    <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('mobileNo2')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <!--------------- Nominee information ----------------------------------------------------- -->

                        <!-- <div class="card-header" style="background:#f44336;color:white;margin:10px;">Nominee Registion Form</div> -->
                        &nbsp;&nbsp;&nbsp;
                        <div><h3>Nominee Information</h3></div>
                        <hr>
                        <div class="form-group row">
                            <div class="col-md-3 col-lg-3 col-sm-12">
                                <label for="nomineeName" ><?php echo e(__('Nominee Name')); ?></label>
                                <input id="nomineeName" type="text" placeholder="Enter Mominee Name  " class="form-control<?php echo e($errors->has('nomineeName') ? ' is-invalid' : ''); ?>" name="nomineeName" value="" required>
                                
                                <?php if($errors->has('nomineeName')): ?>
                                    <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('nomineeName')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="col-md-3 col-lg-3 col-sm-12">
                                <label for="nomineeFatherName"><?php echo e(__('S/O,D/O,W/O')); ?></label>
                                <input id="nomineeFatherName" type="text" placeholder="Enter father Name " class="form-control<?php echo e($errors->has('nomineeFatherName') ? ' is-invalid' : ''); ?>" name="nomineeFatherName" value="" required>
                                <?php if($errors->has('nomineeFatherName')): ?>
                                    <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('nomineeFatherName')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        <!-- </div> -->
                        <!-- <div class="form-group row"> -->
                            <div class="col-md-3 col-lg-3 col-sm-12">
                                <label for="nomineeCnicNo"><?php echo e(__('Nominee CNIC Number')); ?></label>
                                <input id="nomineeCnicNo"  type="tel" size="15" maxlength="15" placeholder="e.g xxxxxxxxxxxxx"  class="form-control<?php echo e($errors->has('nomineeCnicNo') ? ' is-invalid' : ''); ?>" name="nomineeCnicNo" value="" pattern="[0-9]{13}" title=" Please match the CNIC No"  required>
                                <?php if($errors->has('nomineeCnicNo')): ?>
                                    <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('nomineeCnicNo')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="col-md-3 col-lg-3 col-sm-12">
                                <label for="nomineePassportNo"><?php echo e(__('Passport No')); ?>&nbsp;&nbsp;(Optional)</label>
                                <input id="nomineePassportNo"  type="tel" size="8" maxlength="8" placeholder="e.g ab123456" class="form-control<?php echo e($errors->has('nomineePassportNo') ? ' is-invalid' : ''); ?>" name="nomineePassportNo" value=""  >
                                <?php if($errors->has('nomineePassportNo')): ?>
                                    <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('nomineePassportNo')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-md-12 col-lg-12 col-sm-12">
                                <label for="relationWithApplicant"><?php echo e(__('Relationship With applicant')); ?></label>
                                <input id="relationWithApplicant" type="text" placeholder="Enter Relation With Applicant " class="form-control<?php echo e($errors->has('relationWithApplicant') ? ' is-invalid' : ''); ?>" name="relationWithApplicant" value=""  required>
                                <?php if($errors->has('relationWithApplicant')): ?>
                                    <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('relationWithApplicant')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-md-12 col-lg-12 col-sm-12">
                                <label for="nomineeMailingAddress"><?php echo e(__('Mailing Address')); ?></label>
                                <input id="nomineeMailingAddress" type="text" placeholder="Enter Mailing Address " class="form-control<?php echo e($errors->has('nomineeMailingAddress') ? ' is-invalid' : ''); ?>" name="nomineeMailingAddress" value=""  >
                                <?php if($errors->has('nomineeMailingAddress')): ?>
                                    <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('nomineeMailingAddress')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <!-- <div class="form-group row">
                            <div class="col-md-12 col-lg-12 col-sm-12">
                                <label for="nomineePermanentAddress"><?php echo e(__('Permanent Address')); ?></label>
                                <input id="nomineePermanentAddress" type="text" placeholder="Enter Permanent Address " class="form-control<?php echo e($errors->has('nomineePermanentAddress') ? ' is-invalid' : ''); ?>" name="nomineePermanentAddress" value=""  >
                                <?php if($errors->has('nomineePermanentAddress')): ?>
                                    <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('nomineePermanentAddress')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div> -->
                        <!-- <div class="form-group row">
                            <div class="col-md-3 col-lg-3 col-sm-12">
                                <label for="nomineeMail"><?php echo e(__('Email')); ?></label>
                                <input id="nomineeMail" type="text" placeholder="Enter Email" class="form-control<?php echo e($errors->has('nomineeMail') ? ' is-invalid' : ''); ?>" name="nomineeMail" value=""  >
                                <?php if($errors->has('nomineeMail')): ?>
                                    <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('nomineeMail')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="col-md-3 col-lg-3 col-sm-12">
                                <label for="nomineePhoneNo"><?php echo e(__('Phone Number')); ?></label>
                                <input id="nomineePhoneNo" type="text" placeholder="Enter Phone No" class="form-control<?php echo e($errors->has('nomineePhoneNo') ? ' is-invalid' : ''); ?>" name="nomineePhoneNo" value=""  >
                                <?php if($errors->has('nomineePhoneNo')): ?>
                                    <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('nomineePhoneNo')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                       
                            <div class="col-md-3 col-lg-3 col-sm-12">
                                <label for="nomineeMobileNo1"><?php echo e(__('Mobile Number')); ?></label>
                                <input id="nomineeMobileNo1" type="text" placeholder="Enter Mobile number" class="form-control<?php echo e($errors->has('nomineeMobileNo1') ? ' is-invalid' : ''); ?>" name="nomineeMobileNo1" value=""  >
                                <?php if($errors->has('nomineeMobileNo1')): ?>
                                    <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('nomineeMobileNo1')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="col-md-3 col-lg-3 col-sm-12">
                                <label for="nomineeMobileNo2"><?php echo e(__('Phone Number (2)')); ?></label>
                                <input id="nomineeMobileNo2" type="text" placeholder="Enter Mobile Numhber 2" class="form-control<?php echo e($errors->has('nomineeMobileNo2') ? ' is-invalid' : ''); ?>" name="nomineeMobileNo2" value=""  >
                                <?php if($errors->has('nomineeMobileNo2')): ?>
                                    <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('nomineeMobileNo2')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div> -->
                      
                    
                    &nbsp;&nbsp;&nbsp;&nbsp;
                    <div><h3>Payment Information</h3></div>
                        <hr>
                    
                        <div class="form-group row">
                            <div class="col-md-6 col-lg-6 col-sm-12">
                                <label for="paymentType" ><?php echo e(__('Cash / Pay Order / Cheque / Adjustment')); ?></label>
                                <input id="paymentType" type="text" placeholder="Enter Property Payment Type " class="form-control<?php echo e($errors->has('paymentType') ? ' is-invalid' : ''); ?>" name="paymentType" value="" required>
                                 
                                <?php if($errors->has('paymentType')): ?>
                                    <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('paymentType')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="col-md-6 col-lg-6 col-sm-12">
                                <label for="transferTo"><?php echo e(__('In Favor of')); ?></label>
                                <input id="transferTo" type="text" placeholder="transferTo " class="form-control<?php echo e($errors->has('transferTo') ? ' is-invalid' : ''); ?>" name="transferTo" value=" Montviro (Pvt) Ltd." required>
                              
                                <?php if($errors->has('transferTo')): ?>
                                    <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('transferTo')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-md-12 col-lg-12 col-sm-12">
                                <label for="bankName"><?php echo e(__('Bank Name')); ?> &nbsp; &nbsp; (Optional)</label>
                                <input id="bankName" type="text" placeholder="Enter bankName " class="form-control<?php echo e($errors->has('bankName') ? ' is-invalid' : ''); ?>" name="bankName" value="" >
                               
                                <?php if($errors->has('bankName')): ?>
                                    <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('bankName')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                           
                        </div>
                        <div class="form-group row">
                            <div class="col-md-6 col-lg-6 col-sm-12">
                                <label for="propertyPurchingDate"><?php echo e(__('Date')); ?></label>
                                <input id="propertyPurchingDate" type="date" placeholder="Enter Date (yyyy-mm-dd) " class="form-control<?php echo e($errors->has('propertyPurchingDate') ? ' is-invalid' : ''); ?>" name="propertyPurchingDate" value="" >
                                <?php if($errors->has('propertyPurchingDate')): ?>
                                    <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('propertyPurchingDate')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="col-md-6 col-lg-6 col-sm-12">
                                <label for="propertyPrice"><?php echo e(__('Total Amount')); ?></label>
                                <input id="propertyPrice" type="text" placeholder="Enter Total Amount " class="form-control<?php echo e($errors->has('propertyPrice') ? ' is-invalid' : ''); ?>" name="propertyPrice" value="" required>
                                <?php if($errors->has('propertyPrice')): ?>
                                    <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('propertyPrice')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-md-12 col-lg-12 col-sm-12">
                                <label for="propertyPaymentProcedure"><?php echo e(__('property Payment Procedure')); ?></label>
                              
                                <select class="form-control" name="propertyPaymentProcedure" id="propertyPaymentProcedure" onchange="paymentProcedure(this);" >
                                    <option value="">Choice Payment Procedure</option>
                                    <option value="Total Amount">Total Amount</option>
                                    <option value="Installment">Installment</option>
                                    <option value="Token">Token</option>
                                    
                                </select>
                                <?php if($errors->has('propertyPaymentProcedure')): ?>
                                    <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('propertyPaymentProcedure')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        &nbsp;&nbsp;
                        <div id="addinstallment">
                        <div><h3>Installment Information</h3></div>
                        <div class="form-group row">
                            <div class="col-md-6 col-lg-6 col-sm-12">
                                <label for=""><?php echo e(__('No of Installments ')); ?></label>
                              
                            
                              
                                  <select id="noOfInstallments" class="form-control" name="noOfInstallments"    >
                                    <option value="">Select No of Installments</option>'+
                                    <option value="1">1</option>
                                    <option value="2">2</option>
                                    <option value="3">3</option>
                                    <option value="4">4</option>
                                    <option value="5">5</option>
                                    <option value="6">6</option>
                                    <option value="7">7</option>
                                    <option value="8">8</option>
                                    <option value="9">9</option>
                                    <option value="10">10</option>
                                    
                                </select>
                                <?php if($errors->has('propertyPaymentProcedure')): ?>
                                    <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('propertyPaymentProcedure')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="col-md-6 col-lg-6 col-sm-12">
                                <label for="downpayment">Down Payment</label>
                                <input id="downpayment" type="number" min="0" placeholder="Enter down payment" class="form-control" name="downpayment" value="" style="border: 1px solid red;">
                               
                            </div>
                        </div>
                        </div>
                        <hr>
                        &nbsp;&nbsp;
                        <div id="addtoken">
                        <div><h3>Token Information</h3></div>
                        <div class="form-group row">
                            <div class="col-md-6 col-lg-6 col-sm-12">
                                <label id="tokenPayment" for="tokenPayment" >Token Payment </label>
                                <input id="tokenPayment" type="number" min="0" placeholder="Enter Token payment" class="form-control" name="tokenPayment" value="" style="border: 1px solid red;">
                              
                            </div>       
                            <div class="col-md-6 col-lg-6 col-sm-12">
                                <label for="remaningPaymentDate">Remaning Payment Date </label>
                                <input id="remaningPaymentDate" type="Date" placeholder="Enter Remaning Payment Date" class="form-control" name="remaningPaymentDate" value="" style="border: 1px solid red;">
                               
                            </div>
                        </div>
                        </div>
                            <!-- <div id="addinstallment">
                            
                           
                            </div>
                            <div id="addtoken">
                           
                           
                            </div> -->
                        
                        
                        <!-- <div class="card-header" style="background:#f44336;color:white;margin:10px;">Witness Form</div> -->
                        &nbsp;&nbsp;&nbsp;&nbsp;
                        <div><h3>Seller Information</h3></div>
                        <hr>
                      
                        <div class="form-group row">    
                            <div class="col-md-12 col-lg-12 col-sm-12">
                                    <label for="witnessName"><?php echo e(__('Seller Name')); ?></label>
                            
                                        <select class="form-control" name="propertySellerId" id="propertySellerId" >
                                        <option value="">Select Seller Name</option>
                                        <?php $__currentLoopData = $seller; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $te): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                               
                                                <option value="<?php echo e($te->id); ?>"><?php echo e($te->sallerName); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                            </div>
                          
                        </div>
                        
                        <!-- <div class="card-header" style="background:#f44336;color:white;margin:10px;">Review Form</div> -->
                        &nbsp;&nbsp;&nbsp;&nbsp;
                        <div><h3>Review</h3></div>
                        <hr>
                        
                        <div class="form-group row">   
                            <div class="col-md-12 col-lg-12 col-sm-12">
                                <label for="comment"><?php echo e(__('Write your Comments')); ?>&nbsp; &nbsp; (Optional)</label>
                               
                                <textarea rows="4" cols="100" id="comment" name="comment" placeholder="Enter your comment" class="form-control<?php echo e($errors->has('comment') ? ' is-invalid' : ''); ?>" name="comment" ></textarea>
                                <?php if($errors->has('comment')): ?>
                                    <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('comment')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div> 
                        </div>
                        
                       
                        
                        <div class="col-md-12 col-lg-12 col-sm-12" style="margin-top:30px;">
                            <div class="form-group row mb-0">
                                <div class="col-md-12 ">
                                    <button type="submit" class="btn btn-lg " style="float:right; background-color:#f44336 !important; color:white;" >
                                        <?php echo e(__('Submit')); ?>

                                    </button>
                                </div>
                            </div>
                        </div>
                    </from>
                    
                </div>
            </div>
        </div>
    </div>
</div>
<!-- javascript code -->
<script>
//add fucntion to test
function paymentProcedure(val){

    
var paymentProcedure = val.value;
var parent = document.getElementById('addinstallment');
var parent = document.getElementById('addtoken');
    if( paymentProcedure == "Total Amount"){

        document.getElementById("addinstallment").style.display ="none";
        document.getElementById("addtoken").style.display ="none";

    }
    else if( paymentProcedure == "Installment"){
        
        document.getElementById("addinstallment").style.display ="block";  
        document.getElementById("addtoken").style.display ="none";
    }
    else if( paymentProcedure == "Token"){
        document.getElementById("addtoken").style.display ="block";                               
        document.getElementById("addinstallment").style.display ="none";
    }

return 0;
}
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>